"""Model Registry Plugins"""

