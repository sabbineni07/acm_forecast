"""Forecaster Plugins"""

