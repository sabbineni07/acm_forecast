"""
Examples module for ACM Forecast Framework

Contains end-to-end examples demonstrating the plugin architecture.
"""
